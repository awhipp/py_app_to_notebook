# Databricks notebook source
# COMMAND ----------
# MAGIC %run ./py2dbrx_importer
# COMMAND ----------
file_uuid = define_checkpoint()
# COMMAND ----------
# MAGIC %run ./queue_to_s3_sample/utilities/boto_helpers
# COMMAND ----------
update_modules_from_checkpoint(file_uuid, 'queue_to_s3_sample.utilities.boto_helpers')
# COMMAND ----------
file_uuid = define_checkpoint()
# COMMAND ----------
# MAGIC %run ./queue_to_s3_sample/utilities/sqs/sqs_utils
# COMMAND ----------
update_modules_from_checkpoint(file_uuid, 'queue_to_s3_sample.utilities.sqs.sqs_utils')
# COMMAND ----------
file_uuid = define_checkpoint()
# COMMAND ----------
# MAGIC %run ./queue_to_s3_sample/utilities/s3/s3_utils
# COMMAND ----------
update_modules_from_checkpoint(file_uuid, 'queue_to_s3_sample.utilities.s3.s3_utils')
# COMMAND ----------
file_uuid = define_checkpoint()
# COMMAND ----------
# MAGIC %run ./queue_to_s3_sample/app
# COMMAND ----------
update_modules_from_checkpoint(file_uuid, 'queue_to_s3_sample.app')
